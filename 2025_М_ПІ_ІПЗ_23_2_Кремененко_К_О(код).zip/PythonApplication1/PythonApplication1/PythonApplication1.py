﻿import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments, set_seed
from sklearn.metrics import precision_recall_fscore_support
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from datasets import Dataset, load_dataset
import numpy as np
import pandas as pd

set_seed(42)
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# -------------------------------
# 1. Завантаження та підготовка даних
# -------------------------------
def prep_huggingface(ds_name, split="train", limit=10):
    ds = load_dataset(ds_name, split=split)
    if limit and len(ds) > limit:
        ds = ds.shuffle(seed=42).select(range(limit))
    return ds

# IMDb
imdb = prep_huggingface("imdb", limit=10)
# GoEmotions
goe = prep_huggingface("go_emotions", split="train", limit=10)

# -------------------------------
# 2. Функція обчислення метрик
# -------------------------------
def compute_metrics_sklearn(y_true, y_pred):
    p, r, f, _ = precision_recall_fscore_support(y_true, y_pred, average="macro")
    return p*100, r*100, f*100

# -------------------------------
# 3. Навчання Logistic Regression та SVM
# -------------------------------
def train_sklearn(texts, labels):
    from sklearn.feature_extraction.text import TfidfVectorizer
    vec = TfidfVectorizer(max_features=50)
    X = vec.fit_transform(texts)
    X_train, X_test, y_train, y_test = train_test_split(X, labels, test_size=0.2, random_state=42)

    models = {
        "Logistic Regression": LogisticRegression(max_iter=20),
        "SVM": LinearSVC(max_iter=20)
    }
    results = {}
    for name, clf in models.items():
        clf.fit(X_train, y_train)
        y_pred = clf.predict(X_test)
        results[name] = compute_metrics_sklearn(y_test, y_pred)
    return results

# -------------------------------
# 4. Навчання моделей HuggingFace (BERT, RoBERTa, GPT2)
# -------------------------------
def train_transformer(model_name, hf_ds):
    # Завантажуємо токенізатор
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    if model_name == "gpt2":
        tokenizer.pad_token = tokenizer.eos_token

    # Визначаємо назву колонки з мітками
    label_col = "label" if "label" in hf_ds.column_names else "labels"

    # Якщо мітки є списком — беремо перший елемент
    if isinstance(hf_ds[0][label_col], list):
        hf_ds = hf_ds.map(lambda e: {"labels": e[label_col][0] if len(e[label_col]) > 0 else 0})
    else:
        hf_ds = hf_ds.rename_column(label_col, "labels")

    # Перенумеровуємо мітки в послідовні індекси: 0,1,2,...
    unique_labels = sorted(set(hf_ds["labels"]))
    label2id = {label: idx for idx, label in enumerate(unique_labels)}
    hf_ds = hf_ds.map(lambda e: {"labels": label2id[e["labels"]]})
    num_labels = len(label2id)

    # Токенізація тексту
    tokenized_ds = hf_ds.map(
        lambda e: tokenizer(e["text"], padding="max_length", truncation=True, max_length=128),
        batched=True
    )

    # Видаляємо зайві колонки
    tokenized_ds = tokenized_ds.remove_columns(
        [col for col in tokenized_ds.column_names if col not in ["input_ids", "attention_mask", "labels"]]
    )

    # Спліт на train/test
    tokenized_ds = tokenized_ds.train_test_split(test_size=0.2, seed=42)
    tokenized_ds.set_format("torch")

    # Ініціалізація моделі
    model = AutoModelForSequenceClassification.from_pretrained(
        model_name,
        num_labels=num_labels
    ).to(DEVICE)

    if model_name == "gpt2":
        model.config.pad_token_id = model.config.eos_token_id

    # Аргументи тренування
    args = TrainingArguments(
        output_dir=f"./tmp/{model_name.replace('/', '_')}",
        evaluation_strategy="epoch",
        per_device_train_batch_size=8,
        per_device_eval_batch_size=8,
        num_train_epochs=1,
        logging_steps=10,
        save_strategy="no",
        disable_tqdm=True
    )

    # Метрики
    def compute_metrics(eval_pred):
        logits, labels = eval_pred
        preds = np.argmax(logits, axis=-1)
        p, r, f, _ = precision_recall_fscore_support(labels, preds, average="macro")
        return {"precision": p * 100, "recall": r * 100, "f1": f * 100}

    # Тренування
    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=tokenized_ds["train"],
        eval_dataset=tokenized_ds["test"],
        compute_metrics=compute_metrics
    )
    trainer.train()

    # Оцінка
    res = trainer.evaluate()
    return res["eval_precision"], res["eval_recall"], res["eval_f1"]




# -------------------------------
# 5. Основний цикл експериментів
# -------------------------------
all_results = []

for ds_name, hf_ds in [("IMDb", imdb), ("GoE", goe)]:
    texts = hf_ds["text"]
    label_col = "labels" if "labels" in hf_ds.column_names else "label"
    raw_labels = hf_ds[label_col]
    if isinstance(raw_labels[0], list):
      labels = [l[0] if len(l) > 0 else 0 for l in raw_labels]  
    else:
      labels = raw_labels


    # Традиційні ML-моделі
    sk_res = train_sklearn(texts, labels)
    for mname, (p, r, f) in sk_res.items():
        all_results.append({"model": mname, "dataset": ds_name, "precision": round(p,1), "recall": round(r,1), "f1": round(f,1)})

    # Трансформери
    for tname in ["bert-base-uncased", "roberta-base", "gpt2"]:
        p, r, f = train_transformer(tname, hf_ds)
        all_results.append({"model": tname.upper(), "dataset": ds_name, "precision": round(p,1), "recall": round(r,1), "f1": round(f,1)})

# -------------------------------
# 6. Формування таблиці результатів
# -------------------------------
df_res = pd.DataFrame(all_results)
print(df_res.pivot_table(index="model", columns="dataset", values=["precision","recall","f1"]))
df_res.to_csv("metrics_results.csv", index=False)
