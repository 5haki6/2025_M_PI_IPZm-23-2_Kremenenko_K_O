﻿import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments, set_seed
from sklearn.metrics import precision_recall_fscore_support
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from datasets import Dataset, load_dataset
import numpy as np
import pandas as pd

set_seed(42)
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# -------------------------------
# 1. Завантаження та підготовка даних
# -------------------------------
def prep_huggingface(ds_name, split="train", limit=1000):
    ds = load_dataset(ds_name, split=split)
    if limit and len(ds) > limit:
        ds = ds.shuffle(seed=42).select(range(limit))
    return ds

# IMDb
imdb = prep_huggingface("imdb", limit=1000)
# GoEmotions
goe = prep_huggingface("go_emotions", split="train", limit=1000)

# -------------------------------
# 2. Функція обчислення метрик
# -------------------------------
def compute_metrics_sklearn(y_true, y_pred):
    p, r, f, _ = precision_recall_fscore_support(y_true, y_pred, average="macro")
    return p*100, r*100, f*100

# -------------------------------
# 3. Навчання Logistic Regression та SVM
# -------------------------------
def train_sklearn(texts, labels):
    from sklearn.feature_extraction.text import TfidfVectorizer
    vec = TfidfVectorizer(max_features=5000)
    X = vec.fit_transform(texts)
    X_train, X_test, y_train, y_test = train_test_split(X, labels, test_size=0.2, random_state=42)

    models = {
        "Logistic Regression": LogisticRegression(max_iter=200),
        "SVM": LinearSVC(max_iter=2000)
    }
    results = {}
    for name, clf in models.items():
        clf.fit(X_train, y_train)
        y_pred = clf.predict(X_test)
        results[name] = compute_metrics_sklearn(y_test, y_pred)
    return results

# -------------------------------
# 4. Навчання моделей HuggingFace (BERT, RoBERTa, GPT2)
# -------------------------------
def train_transformer(model_name, hf_ds):
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    if model_name == "gpt2":
        tokenizer.pad_token = tokenizer.eos_token

    # Якщо назва мітки — 'labels', перейменування не потрібне
    if "label" in hf_ds.column_names:
        hf_ds = hf_ds.rename_column("label", "labels")

    # Токенізація
    tokenized_ds = hf_ds.map(
        lambda e: tokenizer(e["text"], padding="max_length", truncation=True, max_length=128),
        batched=True
    )

    # Залишаємо лише необхідні колонки
    tokenized_ds = tokenized_ds.remove_columns(
        [col for col in tokenized_ds.column_names if col not in ["input_ids", "attention_mask", "labels"]]
    )

    # Тренувальний/тестовий спліт
    tokenized_ds = tokenized_ds.train_test_split(test_size=0.2, seed=42)
    tokenized_ds.set_format("torch")

    # Завантаження моделі
    model = AutoModelForSequenceClassification.from_pretrained(
        model_name,
        num_labels=len(set(hf_ds["labels"]))
    ).to(DEVICE)

    if model_name == "gpt2":
        model.config.pad_token_id = model.config.eos_token_id

    # Параметри тренування
    args = TrainingArguments(
        output_dir=f"./tmp/{model_name.replace('/', '_')}",
        evaluation_strategy="epoch",
        per_device_train_batch_size=8,
        per_device_eval_batch_size=8,
        num_train_epochs=1,
        logging_steps=10,
        save_strategy="no",
        disable_tqdm=True
    )

    # Обчислення метрик
    def compute_metrics(eval_pred):
        logits, labels = eval_pred
        preds = np.argmax(logits, axis=-1)
        p, r, f, _ = precision_recall_fscore_support(labels, preds, average="macro")
        return {"precision": p * 100, "recall": r * 100, "f1": f * 100}

    # Тренування
    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=tokenized_ds["train"],
        eval_dataset=tokenized_ds["test"],
        compute_metrics=compute_metrics
    )
    trainer.train()
    res = trainer.evaluate()
    return res["eval_precision"], res["eval_recall"], res["eval_f1"]


# -------------------------------
# 5. Основний цикл експериментів
# -------------------------------
all_results = []

for ds_name, hf_ds in [("IMDb", imdb), ("GoE", goe)]:
    texts = hf_ds["text"]
    label_col = "labels" if "labels" in hf_ds.column_names else "label"
    labels = hf_ds[label_col]


    # Традиційні ML-моделі
    sk_res = train_sklearn(texts, labels)
    for mname, (p, r, f) in sk_res.items():
        all_results.append({"model": mname, "dataset": ds_name, "precision": round(p,1), "recall": round(r,1), "f1": round(f,1)})

    # Трансформери
    for tname in ["bert-base-uncased", "roberta-base", "gpt2"]:
        p, r, f = train_transformer(tname, hf_ds)
        all_results.append({"model": tname.upper(), "dataset": ds_name, "precision": round(p,1), "recall": round(r,1), "f1": round(f,1)})

# -------------------------------
# 6. Формування таблиці результатів
# -------------------------------
df_res = pd.DataFrame(all_results)
print(df_res.pivot_table(index="model", columns="dataset", values=["precision","recall","f1"]))
df_res.to_csv("metrics_results.csv", index=False)
